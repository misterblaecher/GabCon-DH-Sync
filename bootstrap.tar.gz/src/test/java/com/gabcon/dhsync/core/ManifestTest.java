package com.gabcon.dhsync.core;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ManifestTest {
    private static final String HASH = "a".repeat(64);

    @Test
    void parsesAndValidatesManifest() {
        SyncManifest manifest = ManifestCodec.fromJson(ManifestCodec.toJson(validManifest()));
        assertDoesNotThrow(() -> ManifestValidator.validate(manifest, "gabcon-world"));
        assertEquals(2, manifest.latestDelta());
    }

    @Test
    void rejectsWrongWorldId() {
        ManifestValidationException ex = assertThrows(ManifestValidationException.class,
                () -> ManifestValidator.validate(validManifest(), "other-world"));
        assertTrue(ex.getMessage().contains("worldId mismatch"));
    }

    @Test
    void rejectsManifestMigrationUntilExplicitlySupported() {
        SyncManifest v2 = new SyncManifest(2, "gabcon-world", "1.21.1", "21.1.251", "3.3.1", 1, 0,
                validManifest().dimensions());
        assertThrows(ManifestValidationException.class, () -> ManifestValidator.validate(v2, "gabcon-world"));
    }

    @Test
    void selectsOnlyMissingDeltasWhenBaseMatches() {
        SyncManifest manifest = validManifest();
        ClientSyncState state = new ClientSyncState(1, Map.of("minecraft:overworld", 1));
        List<DeltaSelector.SelectedAsset> selected = DeltaSelector.select(manifest, state);
        assertEquals(1, selected.size());
        assertEquals(2, selected.getFirst().asset().version());
        assertEquals(DeltaSelector.Kind.DELTA, selected.getFirst().kind());
    }

    @Test
    void selectsBootstrapAndDeltasWhenBaseDiffers() {
        List<DeltaSelector.SelectedAsset> selected = DeltaSelector.select(validManifest(), new ClientSyncState(0, Map.of()));
        assertEquals(3, selected.size());
        assertEquals(DeltaSelector.Kind.BOOTSTRAP, selected.getFirst().kind());
    }

    @Test
    void alreadyUpToDateSelectsNothing() {
        ClientSyncState state = new ClientSyncState(1, Map.of("minecraft:overworld", 2));
        assertTrue(DeltaSelector.select(validManifest(), state).isEmpty());
    }

    @Test
    void pathTraversalIsRejected() {
        SyncManifest.Asset bad = new SyncManifest.Asset(1, "../escape.zip", 1, HASH,
                "https://example.invalid/escape.zip", 1);
        SyncManifest manifest = new SyncManifest(1, "gabcon-world", "1.21.1", "21.1.251", "3.3.1", 1, 0,
                Map.of("minecraft:overworld", new SyncManifest.DimensionManifest(bad, List.of())));
        assertThrows(ManifestValidationException.class, () -> ManifestValidator.validate(manifest, "gabcon-world"));
    }

    private static SyncManifest validManifest() {
        SyncManifest.Asset bootstrap = new SyncManifest.Asset(1, "overworld-base-v1.gcdh", 100, HASH,
                "https://github.com/misterblaecher/GabCon-DH-Sync/releases/download/maps/overworld-base-v1.gcdh", 1);
        SyncManifest.Asset d1 = new SyncManifest.Asset(1, "overworld-delta-1.gcdh", 10, HASH,
                "https://github.com/misterblaecher/GabCon-DH-Sync/releases/download/maps/overworld-delta-1.gcdh", 1);
        SyncManifest.Asset d2 = new SyncManifest.Asset(2, "overworld-delta-2.gcdh", 10, HASH,
                "https://github.com/misterblaecher/GabCon-DH-Sync/releases/download/maps/overworld-delta-2.gcdh", 1);
        return new SyncManifest(1, "gabcon-world", "1.21.1", "21.1.251", "3.3.1", 1, 2,
                Map.of("minecraft:overworld", new SyncManifest.DimensionManifest(bootstrap, List.of(d1, d2))));
    }
}
