package com.gabcon.dhsync.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RegionChangeTrackerTest {
    @Test
    void groupsChunksIntoVanillaSizedPublicationBucketsWithNegativeCoordinates() {
        RegionChangeTracker tracker = new RegionChangeTracker();
        tracker.markChunk("minecraft:overworld", 0, 31);
        tracker.markChunk("minecraft:overworld", 31, 0);
        tracker.markChunk("minecraft:overworld", -1, -1);
        assertEquals(2, tracker.pendingRegionCount());
        assertEquals(2, tracker.snapshot().stream().mapToLong(RegionChangeTracker.RegionChange::chunkSaveEvents).max().orElseThrow());
    }
}
