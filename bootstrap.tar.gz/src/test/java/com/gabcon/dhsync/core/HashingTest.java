package com.gabcon.dhsync.core;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HashingTest {
    @TempDir Path temp;

    @Test
    void sha256MatchesKnownValue() throws Exception {
        Path file = temp.resolve("hello.txt");
        Files.writeString(file, "hello", StandardCharsets.UTF_8);
        assertEquals("2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824", Hashing.sha256(file));
    }
}
